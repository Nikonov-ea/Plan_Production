## How to add Gantt userControl on your page
* Put reference to gantt library and add ganttUC usercontrol on your page

## Structure of source for ganttUC
* GanttUC.Groups : List<**GanttGroup**>
	* GanttGroup.Rows : List<**GanttRow**>
		*  GanttRow.Items : List<**GanttItem**>
  

## How to add items in ganttUC UserControl*
* Create collection of **GanttGroup**, where every group has any **Caption** and subcollection of **Rows** (GanttRow). Into every Row insert a collection of **Items** (derived from GanttItem)
 
## Example
{{
gantt.Groups.Clear();
gantt.Start = DateTime.Now.AddHours(-2);
gantt.End = DateTime.Now;
gantt.Groups.AddRange(new List<GanttGroup>() { 
    new GanttGroup
    {
        Caption = "MyGroup",
        Rows = new List<GanttRow>() { 
            new GanttRow { 
                Caption = "Name 1",
                Items = new List<GanttItem>() 
                    { 
                      new GanttItem {Caption = "Item1", Start = DateTime.Now.AddHours(-1), End=DateTime.Now.AddMinutes(-20) }
                    } } ,
            new GanttRow { 
                Caption = "Name 2",
                Items = new List<GanttItem>() 
                    { 
                      new GanttItem {Caption = "Item2", Start = DateTime.Now.AddMinutes(-130), End=DateTime.Now.AddMinutes(-35) } 
                    } } } 
    }
    ,
    new GanttGroup
    {
        Caption = "MyGroup 2",
        Rows = new List<GanttRow>() { 
            new GanttRow { 
                Caption = "Name 3",
                Items = new List<GanttItem>() 
                    { 
                     new GanttItem {Caption = "Item3", Start = DateTime.Now.AddMinutes(-70), End=DateTime.Now.AddMinutes(-10) } ,
                     new GanttItem {Caption = "Item4", Start = DateTime.Now.AddMinutes(-110), End=DateTime.Now.AddMinutes(-97) } } 
                    }
            } } }
});
gantt.Refresh();
}}