**Project Description**
A Gantt chart, which I created for my use...   It's not perfect, but if you find it useful for you, feel free to use it :) 

**View Documentation** [http://wpfgantt.codeplex.com/documentation](http://wpfgantt.codeplex.com/documentation)

Note: yes, **some** things are in CZECH language, it won't be hard to deduce and translate (or ask me) ...
So please tell me if this worked for you if you are going to use it :)

